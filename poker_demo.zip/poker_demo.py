# -*- coding: utf-8 -*-
"""
Created on Tue Aug 25 01:50:05 2020

@author: canseco
"""
import random

def CreatePoker():
    poker = []
    for i in range(1, 5):
        for j in range(1, 14):
            poker.append(i*100+j)
            
    return poker

def DisplayCard(num):
    suits = ["♣", "♢", "♡", "♠"]
    numbers = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]
    suit_id = int(num / 100) - 1
    num_id = num % 100 - 1
   
    return suits[suit_id] + numbers[num_id]

def ShuffleCards(card_list):
    random.shuffle(card_list)
    
def DisplayCards(card_list):
    for c in card_list:
        print(DisplayCard(c), end=', ')

def DealCards(card_list):
    hand = []
    if len(card_list) > 5:
        for i in range(5):
            hand.append(card_list.pop(0))
    return hand

# 順子
def IsStraight(card_list):
    result = False
    
    if len(card_list) == 5:
    # this is your homework.....
    
    return result

# 同花順
def IsStraightFlush(card_list):
    result = False

    if len(card_list) == 5:
    # this is your homework.....

    return result

# for more information - https://en.wikipedia.org/wiki/List_of_poker_hands
# you can do more ....

# main program begins here
p_host = CreatePoker()
print("\nDealer....")       
DisplayCards(p_host)
        
print("\n\nafter shuffling....")       
ShuffleCards(p_host)
DisplayCards(p_host)

p1 = DealCards(p_host)
p2 = DealCards(p_host)

print("\n\nplayer 1....") 
DisplayCards(p1)

print("\n\nplayer 2....") 
DisplayCards(p2)

print("\n")
DisplayCards(p_host)
      
      
      
      
      
      
      

    
   
    
   
    
   
    
   
    
   
    
   
    
   
    
   
    
   
    
   
    
   
    
   
    
   

# def DisplayPoker(poker_list):  
#     for x in poker_list:
#         print(DisplayCard(x), end=' ')
#     print()
        
# def ShufflePoker(poker_list):
#     temp_list = poker_list
#     poker_list.reverse()
    
    
    
# myPoker = CreatePoker()
# DisplayPoker(myPoker)
# ShufflePoker(myPoker)
# print('After shffule')
# DisplayPoker(myPoker)
    
# print(CreatePoker())
# print(DisplayCard(401))